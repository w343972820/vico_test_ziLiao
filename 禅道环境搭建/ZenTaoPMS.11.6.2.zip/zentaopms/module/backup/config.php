<?php
$config->backup = new stdclass();
$config->backup->holdDays = 14;
$config->backup->setting  = '';
