$(document).ready(function()
{
    $('#zerocaseTab').addClass('btn-active-text');
});
