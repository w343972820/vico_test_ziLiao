<?php
$lang->index->common = '首頁';
$lang->index->index  = '首頁';
