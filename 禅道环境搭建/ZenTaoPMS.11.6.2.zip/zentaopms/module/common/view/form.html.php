<?php if($extView = $this->getExtViewFile(__FILE__)){include $extView; return helper::cd();}?>
<?php
// js::import($jsRoot . 'jquery/form/min.js');
// js::import($jsRoot . 'jquery/form/zentao.js');
// Now jquery.form is built in zui zentao edition, no need to include them.
?>
